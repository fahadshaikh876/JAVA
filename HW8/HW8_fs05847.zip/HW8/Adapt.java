import java.util.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Component;
import java.awt.Graphics;

public class Adapt extends Sprite {
    int x, y;
    RedSprite redsprite = new RedSprite(x, y);

    public Adapt(int x, int y) {
        super(x, y);
        this.redsprite = new RedSprite(x, y);

    }

    public void move(Canvas c) {
        redsprite.moveMe(c);
    }

    public void animate(Canvas c) {
        redsprite.animateMe(c);
        
    }

    public void draw(Component c, Graphics g) {
        redsprite.drawMe(c, g);
      }
      public void highlight(Component c, Graphics g){
          redsprite.highlightMe(c, g);
      }

}